import json
import boto3
import joblib 

def predict(data):
  return model.predict([data])
  

MODEL_FILE_NAME = 'model.joblib'
model = joblib.load(MODEL_FILE_NAME)


def lambda_handler(event, context):
    
    return {
        'statusCode': 200,
        'body': predict(event['payload']).tolist()[0]
}