import json
import boto3
import numpy as np
import pandas as pd
s3_client=boto3.client('s3')
def lambda_handler(event, context):
    print(event)
    s3_client.download_file(event['input']['bucket'],event['input']['key'],"/tmp/input.csv")
    s3_client.download_file(event['results']['bucket'],event['results']['key'],"/tmp/results")
    df_input = pd.read_csv("/tmp/input.csv", header=None)
    results = np.fromfile("/tmp/results")
    df_input[4] = results.tolist()
    df_input[4] = df_input[4].map({ 0: "Iris-setosa", 1: "Iris-versicolor", 2: "Iris-virginica"})
    # TODO implement
    df_input.to_csv("/tmp/processed_results.csv")
    s3_client.upload_file("/tmp/processed_results.csv",event['results']['bucket'],"processed-"+event['results']['key'])
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
