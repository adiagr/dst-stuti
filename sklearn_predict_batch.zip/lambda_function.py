import json
import boto3
import joblib 
from csv import reader

# read the CSV file
def load_csv(filename):
    data = list()
    # Open file in read mode
    file = open(filename,"r")
    # Reading file
    lines = reader(file)
    csv_reader = reader(file)
    for row in csv_reader:
        if not row:
            continue
        data.append(row)
    return data

def predict(data):
  return model.predict(data)
  
MODEL_FILE_NAME = 'model.joblib'
model = joblib.load(MODEL_FILE_NAME)
s3_client = boto3.client("s3")

def lambda_handler(event, context):
    s3_client.download_file(
    event['detail']['bucket']['name'], event['detail']['object']['key'], "/tmp/data.csv")
    predict(load_csv('/tmp/data.csv')).tofile("/tmp/results.csv")
    s3_client.upload_file("/tmp/results.csv", "dst-stuti-results", "results/"+event['detail']['object']['key'])
    return {
            "input": {
                "bucket":  event['detail']['bucket']['name'],
                "key":  event['detail']['object']['key']
            },
            "results": {
                "bucket": "dst-stuti-results",
                "key": "results/"+event['detail']['object']['key']
            }
    }
